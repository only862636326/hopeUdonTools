﻿
using UdonSharp;
using UnityEngine;
using UnityEngine.UI;
using VRC.SDKBase;
using VRC.Udon;


namespace HopeTools
{

    [UdonBehaviourSyncMode(BehaviourSyncMode.None)]
    public class huComponetSimple : UdonSharpBehaviour
    {
        public Transform active_obj;
        #region public fun
        [HideInInspector] public object[] exter_active_tf = new object[3];

        private Transform _title_transform;
        private Transform _content_transform;
        private Toggle _component_active_toggle;

        private void PublicInitGetComponet()
        {
            _title_transform = this.transform;
            var prt = transform.parent;
            var idx = this.transform.GetSiblingIndex() + 1;
            _content_transform = prt.GetChild(idx);
            _component_active_toggle = this.transform.Find("ToggleActive").GetComponent<Toggle>();

            exter_active_tf[0] = _title_transform;
            exter_active_tf[1] = _content_transform;
        }

        public void ToggleActive()
        {
            if (active_obj == null)
                return;
            if (_op_componet == null)
                return;
            //_op_componet.enabled = _component_active_toggle.isOn;
        }


        public void LogMessge(object messge)
        {
            Debug.Log("                      [HopeUnityGameObjCompnet] " + messge.ToString());
        }

        void Start()
        {
            PublicInitGetComponet();
            InitGetComponet();
        }

        public void UpdataVal()
        {
            //_op_componet = this.GetComponent<>();
            exter_active_tf[2] = _op_componet;
            InitSetComponetVal();
        }

        #endregion publicfun

        private object _op_componet;

        public void InitGetComponet()
        {
            ;
        }
        public void InitSetComponetVal()
        {
            ;
        }
    }
}